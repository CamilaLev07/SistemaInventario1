
public class Date {

    public static java.util.Date valueOf(String fechaOrden) {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'valueOf'");
    }

}
